<?php
defined( 'ABSPATH' ) || exit;

global $wpdb;

/**
 * Growth Plan Command Center.
 *
 * Aggregates Trend Scout 2026, Rising Search Signals, and Niche Expansion
 * into a single high-velocity editorial dashboard.
 */

$news_engine   = new VMSB_News();
$trends_engine = new VMSB_Trends();
$brain         = new VMSB_Brain();
$profile       = $brain->profile();

// 1. Live Rising Signals (from GSC Velocity)
$velocity_signals = $trends_engine->analyze_velocity();

// 2. Rising News Topics (Filtered Google Trends)
$rising_trends = $trends_engine->get_rising_signals(8);

// 3. System Check
$news_enabled = (int) VMSB_Settings::get( 'news_enabled' );
?>
<div class="wrap vmsb">
	<header class="vmsb-head">
		<div>
			<p class="vmsb-eyebrow">Strategic Content Velocity</p>
			<h1>Growth Plan</h1>
			<p class="vmsb-sub">Discovery of new territories and real-time viral trends.</p>
		</div>
		<div class="vmsb-head-actions">
			<button class="vmsb-btn vmsb-btn-ghost" data-vmsb="trend-scout">Refresh Trends</button>
			<button class="vmsb-btn vmsb-btn-ghost" data-vmsb="niche-plan" data-body='{"count":15}'>Trigger Niche Expansion</button>
			<button class="vmsb-btn vmsb-btn-ghost" data-vmsb="plan" data-body='{"count":20}'>Plan next 20</button>
			<?php if ( VMSB_License::has_feature('trend_scout') ) : ?>
				<button class="vmsb-btn vmsb-btn-gold" data-vmsb="news-scout" data-confirm="Trend Scout will fetch live news and propose new trending articles. Continue?">Run Trend Scout 2026</button>
			<?php else : ?>
				<a href="<?php echo admin_url('admin.php?page=vmsb-plans'); ?>" class="vmsb-btn vmsb-btn-gold" style="opacity: 0.7;">Unlock Trend Scout 2026</a>
			<?php endif; ?>
		</div>
	</header>

	<div class="vmsb-grid" style="grid-template-columns: 2fr 1fr; gap: 30px;">

		<section>
			<!-- BULK IMPORT -->
			<div class="vmsb-card" style="margin-bottom:30px; border-top: 4px solid var(--gold);">
				<div class="vmsb-flex-space" style="margin-bottom:14px;">
					<h2 style="margin:0;">Bulk Authority Import</h2>
					<p class="vmsb-note" style="margin:0;">Transform raw topics into 90+ score briefs instantly.</p>
				</div>
				<div id="vmsb-bulk-topics-form" class="vmsb-stack-form">
					<textarea name="topics" data-list rows="6" placeholder="Paste your top topics (one per line)..." style="background:var(--ink); border:1px solid var(--line); color:var(--text); padding:15px; border-radius:8px;"></textarea>

					<div style="display:flex; gap: 20px; margin-top:15px; align-items: flex-end;">
						<label style="flex:1; margin:0;">
							<span class="vmsb-note">Output Language (optional)</span>
							<input type="text" name="language" placeholder="e.g. Spanish, Hindi — blank = site default" style="width:100%; height:42px; border-radius:8px;">
						</label>
						<button class="vmsb-btn vmsb-btn-gold" data-vmsb="import-topics" data-vmsb-form="vmsb-bulk-topics-form" style="height:42px;">Import & Brief Topics</button>
					</div>

					<p class="vmsb-note" style="margin-top:15px;">New items will appear in the <strong>Pipeline</strong> for drafting.</p>

					<div style="margin-top:15px; text-align:right;">
						<button class="vmsb-btn vmsb-btn-ghost vmsb-btn-sm" data-vmsb="pull-bulk-topics">Pull from Sheet (Bulk Topics Tab)</button>
					</div>
				</div>
			</div>

			<div class="vmsb-flex-space" style="margin-bottom: 20px;">
				<h2 style="margin:0; font-family:var(--serif);">Viral Discovery (2026 Signals)</h2>
				<span class="vmsb-tag vmsb-tag-good">Live RSS Active</span>
			</div>

			<div class="vmsb-grid" style="margin-bottom: 30px; grid-template-columns: repeat(3, 1fr);">
				<?php
				$db = $GLOBALS['wpdb'];
				$intent_data = $db->get_results("SELECT intent, COUNT(*) as n FROM {$db->prefix}vmsb_keywords WHERE intent IS NOT NULL AND intent != '' GROUP BY intent");
				$intent_colors = array('informational' => 'var(--accent-blue)', 'commercial' => 'var(--gold)', 'transactional' => 'var(--good)', 'navigational' => 'var(--accent-purple)');
				foreach ($intent_data as $id) :
				?>
					<div class="vmsb-card" style="padding:15px; border-bottom: 3px solid <?php echo $intent_colors[$id->intent] ?? 'var(--line)'; ?>;">
						<span class="vmsb-note" style="text-transform:uppercase; font-size:10px;"><?php echo esc_html($id->intent); ?></span>
						<p style="margin:5px 0 0; font-weight:700; font-size:20px;"><?php echo (int)$id->n; ?> KWs</p>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="vmsb-cards" style="grid-template-columns: 1fr; gap: 20px;">
				<?php if ( empty($rising_trends) ) : ?>
					<div class="vmsb-card vmsb-empty" style="padding:40px;">
						<p class="vmsb-note">No relevant rising trends detected. Run Scout to trigger discovery.</p>
					</div>
				<?php else : ?>
					<?php foreach ( $rising_trends as $trend ) : ?>
						<article class="vmsb-card" style="display:flex; justify-content:space-between; align-items:center; padding: 20px 25px;">
							<div>
								<span class="vmsb-tag vmsb-tag-blue" style="margin-bottom:8px;">Google Trend</span>
								<h3 style="margin:5px 0; font-size:17px;"><?php echo esc_html($trend); ?></h3>
								<p class="vmsb-note" style="margin:0;">High viral potential for <?php echo esc_html($profile['name']); ?>.</p>
							</div>
							<div class="vmsb-row-actions">
								<button class="vmsb-btn vmsb-btn-ghost vmsb-btn-sm" data-vmsb="plan" data-body='{"keyword":"<?php echo esc_attr($trend); ?>", "count":1}'>Push to Pipeline</button>
							</div>
						</article>
					<?php endforeach; ?>
				<?php endif; ?>
			</div>
		</section>

		<aside>
			<div class="vmsb-card vmsb-card-wide" style="border-top: 4px solid var(--good); margin-bottom: 30px;">
				<h3 style="margin:0 0 15px; font-size:14px; text-transform:uppercase; letter-spacing:1px; color:var(--good);">Impression Velocity</h3>
				<p class="vmsb-note">Keywords with >50% growth in the last 7 days.</p>

				<div style="margin-top:20px;">
					<?php if ( empty($velocity_signals) ) : ?>
						<p class="vmsb-note">Waiting for Search Console data (Last 7 days vs Previous 7 days)...</p>
					<?php else : ?>
						<ul style="margin:0; list-style:none; padding:0;">
							<?php foreach ( $velocity_signals as $sig ) : ?>
								<li style="display:flex; justify-content:space-between; padding: 12px 0; border-bottom:1px solid var(--line);">
									<span style="font-weight:600; font-size:13px;"><?php echo esc_html($sig['keyword']); ?></span>
									<span style="color:var(--good); font-weight:700;">+<?php echo esc_html($sig['growth']); ?></span>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			</div>

			<div class="vmsb-card vmsb-card-wide" style="border-top: 4px solid var(--gold);">
				<h3 style="margin:0 0 15px; font-size:14px; text-transform:uppercase; letter-spacing:1px; color:var(--gold);">Top Opportunity</h3>
				<p class="vmsb-note">Highest score keywords ready for the pipeline.</p>

				<div style="margin-top:20px;">
					<?php
					$top_opps = ( new VMSB_Keywords() )->top( 5 );
					if ( empty($top_opps) ) : ?>
						<p class="vmsb-note">Run research to find opportunities...</p>
					<?php else : ?>
						<ul style="margin:0; list-style:none; padding:0;">
							<?php foreach ( $top_opps as $opp ) : ?>
								<li style="display:flex; justify-content:space-between; align-items:center; padding: 12px 0; border-bottom:1px solid var(--line);">
									<span style="font-weight:600; font-size:13px; max-width:140px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;"><?php echo esc_html($opp->keyword); ?></span>
									<button class="vmsb-mini-btn" data-vmsb="plan" data-body='{"keyword":"<?php echo esc_attr($opp->keyword); ?>", "count":1}'>Plan</button>
								</li>
							<?php endforeach; ?>
						</ul>
					<?php endif; ?>
				</div>
			</div>

			<div class="vmsb-card vmsb-card-wide" style="margin-top:30px; background: linear-gradient(135deg, rgba(29, 209, 161, 0.1) 0%, transparent 100%);">
				<h3 style="margin:0 0 15px; font-size:14px; text-transform:uppercase; letter-spacing:1px; color:var(--good);">Growth Victory ROI</h3>
				<?php $summary = VMSB_Outcome_Ledger::counts(); ?>
				<div class="vmsb-figure">
					<span class="vmsb-number" style="font-size:32px; color:var(--good);">+<?php echo number_format($summary['net_clicks']); ?></span>
				</div>
				<p class="vmsb-note">Total organic clicks gained via AI optimizations (30d).</p>
			</div>
		</aside>

	</div>

	<div id="vmsb-output" class="vmsb-output" hidden></div>
</div>
