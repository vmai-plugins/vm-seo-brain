<?php
defined( 'ABSPATH' ) || exit;

/**
 * Model Sync Engine.
 * Fetches available models from configured providers.
 */
class VMSB_Model_Sync {

	public static function sync_all() {
		$providers = array( 'openai', 'gemini', 'openrouter', 'aipuffer', 'ollama' );
		$all_models = array();
		$fallbacks = (array) VMSB_Settings::get( 'ai_fallbacks', array() );
		$primary = VMSB_Settings::get( 'ai_primary' );

		foreach ( $providers as $provider ) {
			// Only sync if configured as primary or enabled in fallbacks
			if ( $provider !== $primary && ! in_array( $provider, $fallbacks ) ) {
				continue;
			}

			$models = self::sync_provider( $provider );
			if ( is_array( $models ) ) {
				$all_models[ $provider ] = $models;
			}
		}

		return $all_models;
	}

	public static function sync_provider( $provider ) {
		try {
			switch ( $provider ) {
				case 'openai':
					return self::sync_openai();
				case 'gemini':
					return self::sync_gemini();
				case 'openrouter':
					return self::sync_openrouter();
				case 'aipuffer':
					return self::sync_aipuffer();
				case 'ollama':
					return self::sync_ollama();
			}
		} catch ( \Throwable $e ) {
			return new WP_Error( 'sync_error', $e->getMessage() );
		}
		return new WP_Error( 'invalid_provider', 'Unknown provider' );
	}

	private static function sync_openai() {
		$key = VMSB_Settings::get( 'openai_key' );
		if ( ! $key ) return new WP_Error( 'no_key', 'OpenAI key missing' );

		$res = wp_remote_get( 'https://api.openai.com/v1/models', array(
			'headers' => array( 'Authorization' => 'Bearer ' . $key )
		) );

		if ( is_wp_error( $res ) ) return $res;
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		$models = array();
		if ( ! empty( $body['data'] ) ) {
			foreach ( $body['data'] as $m ) {
				if ( preg_match( '/^(gpt|o1|o3)/', $m['id'] ) ) {
					$models[] = array( 'id' => $m['id'], 'name' => $m['id'] );
				}
			}
		}
		update_option( 'vmsb_models_openai', $models );
		return $models;
	}

	private static function sync_gemini() {
		$key = VMSB_Settings::get( 'gemini_key' );
		if ( ! $key ) return new WP_Error( 'no_key', 'Gemini key missing' );

		$url = "https://generativelanguage.googleapis.com/v1beta/models?key=" . rawurlencode( $key );
		$res = wp_remote_get( $url );

		if ( is_wp_error( $res ) ) return $res;
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		$models = array();
		if ( ! empty( $body['models'] ) ) {
			foreach ( $body['models'] as $m ) {
				$id = str_replace( 'models/', '', $m['name'] );

				// Categorize for UI
				$type = ( strpos($id, 'imagen') !== false ) ? 'Image' : 'Text';
				$models[] = array(
					'id'   => $id,
					'name' => "{$type}: " . ($m['displayName'] ?? $id),
					'type' => strtolower($type)
				);
			}
		}
		update_option( 'vmsb_models_gemini', $models );
		return $models;
	}

	private static function sync_openrouter() {
		$key = VMSB_Settings::get( 'openrouter_key' );
		if ( ! $key ) return new WP_Error( 'no_key', 'OpenRouter key missing' );

		$res = wp_remote_get( 'https://openrouter.ai/api/v1/models', array(
			'headers' => array( 'Authorization' => 'Bearer ' . $key )
		) );

		if ( is_wp_error( $res ) ) return $res;
		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		$models = array();
		if ( ! empty( $body['data'] ) ) {
			foreach ( $body['data'] as $m ) {
				$models[] = array( 'id' => $m['id'], 'name' => $m['name'] ?? $m['id'] );
			}
		}
		update_option( 'vmsb_models_openrouter', $models );
		return $models;
	}

	private static function sync_aipuffer() {
		$all_models = array();
		$base = untrailingslashit( VMSB_Settings::get( 'aipuffer_url' ) );
		$key  = VMSB_Settings::get( 'aipuffer_key' );
		$is_local = empty($base) || ( untrailingslashit($base) === untrailingslashit(home_url()) );

		// 1. Remote Sync
		if ( ! $is_local && $base ) {
			// Try AI Power's internal model list if available via REST
			$url = $base . '/wp-json/aipkit/v1/models';
			$res = wp_remote_get( add_query_arg('aipkit_api_key', $key, $url) );

			if ( ! is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200 ) {
				$body = json_decode( wp_remote_retrieve_body($res), true );
				if ( is_array($body) ) {
					foreach ( $body as $m ) {
						if ( is_array($m) && isset($m['id']) ) {
							$all_models[] = array( 'id' => $m['id'], 'name' => "Remote Puffer: " . ($m['name'] ?? $m['id']) );
						}
					}
				}
			}
		}

		// 2. Local AI Power (AIPKit)
		if ( class_exists( '\WPAICG\Core\AIPKit_Models_API' ) ) {
			try {
				$aip_providers = array( 'OpenAI', 'Google', 'Claude', 'OpenRouter' );
				foreach ( $aip_providers as $ap ) {
					$models = \WPAICG\Core\AIPKit_Models_API::get_models( $ap );
					if ( ! is_wp_error( $models ) && is_array( $models ) ) {
						foreach ( $models as $m ) {
							$all_models[] = array( 'id' => $m['id'], 'name' => "AI Power ({$ap}): " . ($m['name'] ?? $m['id']) );
						}
					}
				}
			} catch ( \Throwable $e ) {
				( new VMSB_Logger() )->error( 'model_sync', 'AI Power model sync failed: ' . $e->getMessage() );
			}
		}

		// Also check for Meow Apps AI Engine models
		if ( function_exists( 'mwai_get_models' ) ) {
			$mwai_models = mwai_get_models();
			foreach ( $mwai_models as $m ) {
				$all_models[] = array( 'id' => $m['id'], 'name' => "AI Engine/Puffer: " . $m['name'] );
			}
		}

		update_option( 'vmsb_models_aipuffer', $all_models );
		return $all_models;
	}

	private static function sync_ollama() {
		$url = VMSB_Settings::get( 'ollama_url' );
		if ( ! $url ) return new WP_Error( 'no_url', 'Ollama URL missing' );

		$res = wp_remote_get( rtrim( $url, '/' ) . '/api/tags' );
		if ( is_wp_error( $res ) ) return $res;

		$body = json_decode( wp_remote_retrieve_body( $res ), true );
		$models = array();
		if ( ! empty( $body['models'] ) ) {
			foreach ( $body['models'] as $m ) {
				$models[] = array( 'id' => $m['name'], 'name' => $m['name'] );
			}
		}
		update_option( 'vmsb_models_ollama', $models );
		return $models;
	}

	public static function get_models( $provider ) {
		return get_option( 'vmsb_models_' . $provider, array() );
	}
}
